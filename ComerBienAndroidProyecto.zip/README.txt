COMERBIEN — Proyecto Android

Incluye:
- Registro por fecha y tipo de comida
- Calorías y proteínas/carbohidratos/grasas calculadas según gramos
- Buscador en línea de Open Food Facts, más 10 alimentos frecuentes como punto de partida
- Escáner de códigos de barras mediante la cámara (si el WebView/Android admite BarcodeDetector); alternativa de búsqueda manual por código
- Historial diario y consulta de días anteriores
- Objetivo calórico configurable
- Exportación JSON y borrado de datos
- Datos locales en el dispositivo (sin cuenta ni conexión)

IMPORTANTE: Este paquete es el PROYECTO FUENTE de Android Studio, no un APK ya compilado.
Para generar el APK:
1. Instala Android Studio y el Android SDK (API 35).
2. Abre la carpeta ComerBienAndroid en Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración se encontrará normalmente en app/build/outputs/apk/debug/app-debug.apk.

El objetivo inicial de 2000 kcal es orientativo; ajústalo en la pantalla Objetivo.
La búsqueda en línea requiere conexión a Internet y usa Open Food Facts; los datos pueden estar incompletos o ser aportados por usuarios. Comprueba etiquetas y cantidades. También puedes introducir alimentos manualmente.


COMPILAR EN LA NUBE (SIN INSTALAR ANDROID STUDIO):
Este proyecto incluye .github/workflows/android-apk.yml para compilar en GitHub Actions.
1. Entra en https://github.com y crea una cuenta si no tienes.
2. Crea un repositorio nuevo (por ejemplo, ComerBien).
3. Sube el contenido de esta carpeta al repositorio, incluyendo la carpeta oculta .github.
4. Abre la pestaña Actions del repositorio.
5. Si te pide confirmación, habilita Actions. Ejecuta "Compilar APK de ComerBien" con Run workflow (o haz push a main).
6. Cuando termine correctamente, abre la ejecución y descarga el artefacto "ComerBien-APK".
7. Descomprime el artefacto; dentro estará app-debug.apk para instalar en Android.

Nota: no he ejecutado la compilación en GitHub desde aquí, así que el APK aún no está generado ni verificado. El flujo de trabajo prepara la compilación remota.
